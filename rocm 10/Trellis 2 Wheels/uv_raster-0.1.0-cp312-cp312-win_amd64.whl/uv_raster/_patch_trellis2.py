"""
Auto-patch Trellis2 files to use uv_raster instead of nvdiffrast's CudaRaster.
Runs once on first import. Creates .bak backups.

Patches:
  1. Single-view bake  -> trellis2_image_to_3d.py (pipelines/trellis2_image_to_3d.py)
     (also trellis2_texturing.py if it matches the same block)
  2. MultiView bake    -> nodes.py  (Trellis2UnWrapAndRasterizer /
                           Trellis2PostProcessAndUnWrapAndRasterizer chunked loop)
  3. MultiView project -> projection/texture_projection_multiview.py
"""
import os
import re
import sys


TRELLIS2_FILES = ['trellis2_image_to_3d.py', 'trellis2_texturing.py']

# --- 1. Single-view bake block (trellis2_image_to_3d.py) -------------------
OLD_BLOCK = re.compile(
    r'        # rasterize\n'
    r'        print\(\'Finalizing mesh \.\.\.\'\)\n'
    r'        ctx = dr\.RasterizeCudaContext\(\)\n'
    r'        uvs_torch = torch\.cat\(\[uvs_torch \* 2 - 1, torch\.zeros_like\(uvs_torch\[:, :1\]\), torch\.ones_like\(uvs_torch\[:, :1\]\)\], dim=-1\)\.unsqueeze\(0\)\n'
    r'        rast, _ = dr\.rasterize\(\n'
    r'            ctx, uvs_torch, faces_torch,\n'
    r'            resolution=\[texture_size, texture_size\],\n'
    r'        \)',
    re.DOTALL
)

REPLACEMENT = (
    '        # rasterize\n'
    '        print(\'Finalizing mesh ...\')\n'
    '        from uv_raster import rasterize as uv_rasterize\n'
    '        rast, _ = uv_rasterize(uvs_torch * 2 - 1, faces_torch, texture_size)'
)

# --- 2. MultiView chunked bake block (nodes.py) ----------------------------
# Appears twice, in Trellis2UnWrapAndRasterizer and
# Trellis2PostProcessAndUnWrapAndRasterizer (identical text).
MV_CHUNK_BLOCK = re.compile(
    r'        # Rasterize in chunks to save memory\n'
    r'        for i in range\(0, out_faces\.shape\[0\], 100000\):\n'
    r'            rast_chunk, _ = dr\.rasterize\(\n'
    r'                ctx, uvs_rast, out_faces\[i:i\+100000\],\n'
    r'                resolution=\[texture_size, texture_size\],\n'
    r'            \)\n'
    r'            mask_chunk = rast_chunk\[\.\.\., 3:4\] > 0\n'
    r'            rast_chunk\[\.\.\., 3:4\] \+= i # Store face ID in alpha channel\n'
    r'            rast = torch\.where\(mask_chunk, rast_chunk, rast\)',
    re.DOTALL
)

MV_CHUNK_REPLACEMENT = (
    '        # Rasterize in chunks to save memory\n'
    '        from uv_raster import rasterize as uv_rasterize\n'
    '        for i in range(0, out_faces.shape[0], 100000):\n'
    '            rast_chunk, _ = uv_rasterize(out_uvs * 2 - 1, out_faces[i:i+100000], texture_size)\n'
    '            mask_chunk = rast_chunk[..., 3:4] > 0\n'
    '            rast_chunk[..., 3:4] += i # Store face ID in alpha channel\n'
    '            rast = torch.where(mask_chunk, rast_chunk, rast)'
)

# --- 3. MultiView projection (projection/texture_projection_multiview.py) --
# 3a. UV-space rasterization (line ~257)
MV_PROJ_UV_BLOCK = re.compile(
    r'    ctx = dr\.RasterizeCudaContext\(\)\n'
    r'    uvs_clip = torch\.cat\(\[out_uvs \* 2\.0 - 1\.0, torch\.zeros_like\(out_uvs\[:, :1\]\), torch\.ones_like\(out_uvs\[:, :1\]\)\], dim=-1\)\.unsqueeze\(0\)\n'
    r'    rast, _ = dr\.rasterize\(ctx, uvs_clip, out_faces\.int\(\), resolution=\[texture_size, texture_size\]\)',
    re.DOTALL
)

MV_PROJ_UV_REPLACEMENT = (
    '    from uv_raster import rasterize as uv_rasterize\n'
    '    rast, _ = uv_rasterize(out_uvs * 2.0 - 1.0, out_faces.int(), texture_size)'
)

# 3b. Camera-space occlusion rasterization (line ~311)
# Matches BOTH the original nvdiffrast call and any previously-applied
# stripped (z-less) uv_raster call, so already-patched files get upgraded
# to pass the full 4D clip (x, y, z, w) -> real z-buffer occlusion.
MV_PROJ_CAM_BLOCK = re.compile(
    r'        cam_rast, _ = (?:'
    r'dr\.rasterize\(ctx, cam_clip, out_faces\.int\(\), resolution=\[occ_res, occ_res\]\)'
    r'|uv_rasterize\(cam_clip\[\.\.\., :2\], out_faces\.int\(\), occ_res\))'
)

MV_PROJ_CAM_REPLACEMENT = (
    '        cam_rast, _ = uv_rasterize(cam_clip, out_faces.int(), occ_res)'
)


def _is_pipelines_dir(c):
    """Return True if `c` is a Trellis2 pipelines/ dir containing the target files."""
    return all(os.path.isfile(os.path.join(c, f)) for f in TRELLIS2_FILES)


def _find_trellis2_dir():
    """Find the `pipelines/` dir containing the two target files.

    Resolution order:
      1. $UV_RASTER_TRELLIS2_DIR (explicit, can point at the Trellis2 repo
         root, the `trellis2` package dir, or the `pipelines` dir directly).
      2. Walking up from this package dir, the running python executable,
         and the current working directory, looking for
         `*/ComfyUI/custom_nodes/ComfyUI-Trellis2/trellis2/pipelines` and
         `*/custom_nodes/ComfyUI-Trellis2/trellis2/pipelines`.
      3. Every entry on sys.path (covers `site-packages`, an editable
         install, or `ComfyUI`'s own custom_nodes dir when added to path).
    """
    override = os.environ.get('UV_RASTER_TRELLIS2_DIR')
    if override:
        for c in (override, os.path.join(override, 'trellis2', 'pipelines')):
            if _is_pipelines_dir(c):
                return os.path.abspath(c)

    starts = [
        os.path.dirname(os.path.abspath(__file__)),
        os.path.dirname(os.path.abspath(sys.executable)) if sys.executable else None,
        os.getcwd(),
    ]

    candidates = []
    for start in starts:
        if not start:
            continue
        d = os.path.abspath(start)
        for _ in range(10):  # walk up to 10 levels
            candidates.append(
                os.path.join(d, 'ComfyUI', 'custom_nodes', 'ComfyUI-Trellis2', 'trellis2', 'pipelines'))
            candidates.append(
                os.path.join(d, 'custom_nodes', 'ComfyUI-Trellis2', 'trellis2', 'pipelines'))
            parent = os.path.dirname(d)
            if parent == d:
                break
            d = parent

    for p in sys.path:
        p = os.path.abspath(p or '.')
        candidates.append(
            os.path.join(p, 'ComfyUI-Trellis2', 'trellis2', 'pipelines'))
        candidates.append(
            os.path.join(p, 'ComfyUI', 'custom_nodes', 'ComfyUI-Trellis2', 'trellis2', 'pipelines'))

    seen = set()
    for c in candidates:
        c = os.path.abspath(c)
        if c in seen:
            continue
        seen.add(c)
        if _is_pipelines_dir(c):
            return c

    return None


def _trellis2_root(pipelines_dir):
    """Derive the ComfyUI-Trellis2 repo root from its pipelines/ dir."""
    return os.path.dirname(os.path.dirname(pipelines_dir))


def _apply(content, patterns, dry_run, fpath, patched):
    """Apply (regex, replacement) pairs to a file. Returns the new content."""
    for regex, repl in patterns:
        new_content, count = regex.subn(repl, content)
        if count:
            content = new_content
    if content != patched['orig']:
        if not dry_run:
            bak_path = fpath + '.bak'
            if not os.path.isfile(bak_path):
                os.rename(fpath, bak_path)
            with open(fpath, 'w', encoding='utf-8') as f:
                f.write(content)
        patched['files'].append(fpath)
    return content


def patch_trellis2(dry_run=False):
    pipelines_dir = _find_trellis2_dir()
    if pipelines_dir is None:
        raise FileNotFoundError(
            "Could not find Trellis2 pipelines directory.\n"
            "  Set UV_RASTER_TRELLIS2_DIR to the Trellis2 repo root, the `trellis2`\n"
            "  package dir, or the `pipelines` dir directly.\n"
            "  Or patch manually: replace `dr.RasterizeCudaContext()` + `dr.rasterize()`\n"
            "  with: `from uv_raster import rasterize as uv_rasterize`\n"
            "        `rast, _ = uv_rasterize(uvs_torch*2-1, faces_torch, texture_size)`"
        )

    root = _trellis2_root(pipelines_dir)
    nodes_path = os.path.join(root, 'nodes.py')
    proj_path = os.path.join(root, 'projection', 'texture_projection_multiview.py')

    patched = {'orig': None, 'files': []}

    # --- pipelines/ files (single-view bake) ---
    for fname in TRELLIS2_FILES:
        fpath = os.path.join(pipelines_dir, fname)
        if not os.path.isfile(fpath):
            continue
        with open(fpath, 'r', encoding='utf-8') as f:
            content = f.read()
        if 'from uv_raster import rasterize' in content:
            continue
        patched['orig'] = content
        _apply(content, [(OLD_BLOCK, REPLACEMENT)], dry_run, fpath, patched)

    # --- nodes.py (MultiView chunked bake, x2) ---
    if os.path.isfile(nodes_path):
        with open(nodes_path, 'r', encoding='utf-8') as f:
            content = f.read()
        if 'from uv_raster import rasterize' not in content:
            patched['orig'] = content
            _apply(content, [(MV_CHUNK_BLOCK, MV_CHUNK_REPLACEMENT)], dry_run, nodes_path, patched)

    # --- projection/texture_projection_multiview.py (MultiView projection) ---
    # The camera occlusion block is applied on every run so files patched with
    # an older z-stripped version get upgraded to the full-clip (z-buffered)
    # call. The UV block only applies to unpatched (original nvdiffrast) files.
    if os.path.isfile(proj_path):
        with open(proj_path, 'r', encoding='utf-8') as f:
            content = f.read()
        patterns = [(MV_PROJ_CAM_BLOCK, MV_PROJ_CAM_REPLACEMENT)]
        if 'from uv_raster import rasterize' not in content:
            patterns.insert(0, (MV_PROJ_UV_BLOCK, MV_PROJ_UV_REPLACEMENT))
        patched['orig'] = content
        _apply(content, patterns, dry_run, proj_path, patched)

    if patched['files']:
        print(f"  [uv_raster] Patched {len(patched['files'])} Trellis2 file(s); backups created with .bak")
    return patched['files']


# Auto-patch on import
try:
    patch_trellis2()
except Exception as e:
    print(f"  [uv_raster] Trellis2 auto-patch skipped: {e}")
