"""
uv_raster — simple UV atlas rasterizer for AMD/HIP.
Replaces nvdiffrast's CudaRaster for UV texture baking.
On import, auto-patches Trellis2 if installed.
"""

# Lazy import of torch + the compiled kernel: the package is imported at
# Python startup (via the .pth bootstrap) purely to run the Trellis2
# auto-patch, so we must not pay the torch/kernel load cost there.
_compiled = None


def _ensure_compiled():
    global _compiled
    if _compiled is None:
        try:
            from . import _rasterize_kernel
            _compiled = True
        except ImportError:
            _compiled = False
    if not _compiled:
        raise RuntimeError(
            "uv_raster extension not compiled. "
            "Run: pip install uv_raster/  (from the package directory)"
        )
    return True


# Auto-patch Trellis2 on import (silent if not found)
try:
    from . import _patch_trellis2
except Exception:
    pass


def rasterize(uvs, faces, texture_size):
    """
    Rasterize UV triangles. Drop-in replacement for dr.rasterize.

    Args:
        uvs: [1, N, 2] or [N, 2] float32 in [-1, 1].
             May also have 3 or 4 columns: (x, y, z) or (x, y, z, w) clip
             coords. Screen position is (x/w, y/w) and the depth buffer uses
             the perspective-corrected z/w, so overlapping surfaces resolve
             like nvdiffrast (nearest wins).
        faces: [F, 3] int32 triangle indices (0-based)
        texture_size: int or (H, W)

    Returns:
        rast: [1, H, W, 4] tensor  (bary0, bary1, z/w, tri_id+1)
              bary0 = barycentric weight of vertex 0, bary1 = weight of vertex 1
              (vertex 2 weight = 1 - bary0 - bary1), matching nvdiffrast's dr.rasterize
        rast_db: [1, H, W, 4] tensor (dudx, dudy, dvdx, dvdy)
              Barycentric pixel derivatives, matching nvdiffrast's rast_db
              (used by dr.texture for mipmapping and dr.interpolate derivatives).
    """
    _ensure_compiled()

    if uvs.dim() == 3:
        uvs = uvs[0]

    if isinstance(texture_size, (list, tuple)):
        H, W = texture_size
        if H != W:
            raise ValueError(f"Only square textures supported, got {H}x{W}")
    else:
        H = W = texture_size

    return _rasterize_kernel.uv_raster_forward(
        uvs.contiguous(), faces.contiguous().int(), H
    )
